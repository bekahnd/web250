<p>Copyright <?php echo date('Y'); ?>, Birds of WNC</p>

<p>Resource:  <a href="https://www.birds.cornell.edu/home/">Cornell Ornathology Lab.</a></p>
