<?php

define("DB_SERVER", "localhost");
define("DB_USER", "web250user");
define("DB_PASS", "8N=YwFDn4]");
define("DB_NAME", "wnc_birds");